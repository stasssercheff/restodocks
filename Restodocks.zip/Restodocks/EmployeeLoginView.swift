//
//  EmployeeLoginView.swift
//  Restodocks
//

import SwiftUI
import CoreData

struct EmployeeLoginView: View {

    @ObservedObject var lang = LocalizationManager.shared
    @Environment(\.dismiss) private var dismiss

    // MARK: - Core Data
    private let context =
        PersistenceController.shared.container.viewContext

    @State private var email = ""
    @State private var password = ""
    @State private var pin = ""

    @State private var loginError = false

    var body: some View {

        Form {

            Section(header: Text(lang.t("login"))) {

                TextField(lang.t("email"), text: $email)
                    .keyboardType(.emailAddress)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled(true)

                SecureField(lang.t("password"), text: $password)

                // ❗️PIN КОМПАНИИ — ВИДИМ
                TextField(lang.t("pin_code"), text: $pin)
                    .textInputAutocapitalization(.characters)
            }

            if loginError {
                Text(lang.t("login_failed"))
                    .foregroundColor(.red)
                    .font(.caption)
            }

            Section {
                Button {
                    login()
                } label: {
                    Text(lang.t("login"))
                }
                .disabled(!canLogin)
            }
        }
        .navigationTitle(lang.t("login"))
    }

    // MARK: - LOGIN LOGIC

    private func login() {

        loginError = false

        let companyRequest: NSFetchRequest<EstablishmentEntity> =
            EstablishmentEntity.fetchRequest()

        guard let company = try? context.fetch(companyRequest).first,
              company.pinCode == pin
        else {
            loginError = true
            return
        }

        let employeeRequest: NSFetchRequest<EmployeeEntity> =
            EmployeeEntity.fetchRequest()

        employeeRequest.predicate = NSPredicate(
            format: "email ==[c] %@ AND password == %@ AND establishment == %@",
            email,
            password,
            company
        )

        guard let employee =
                try? context.fetch(employeeRequest).first
        else {
            loginError = true
            return
        }

        // ✅ помечаем как активного
        employee.isActive = true
        try? context.save()

        dismiss()
    }

    private var canLogin: Bool {
        !email.isEmpty &&
        !password.isEmpty &&
        !pin.isEmpty
    }
}
