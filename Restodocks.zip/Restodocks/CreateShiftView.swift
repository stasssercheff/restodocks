//
//  CreateShiftView.swift
//  Restodocks
//

import SwiftUI
import CoreData

struct CreateShiftView: View {

    // Core Data
    @Environment(\.managedObjectContext) private var context
    @Environment(\.dismiss) private var dismiss

    // сотрудники
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \EmployeeEntity.fullName, ascending: true)],
        animation: .default
    )
    private var employees: FetchedResults<EmployeeEntity>

    // state
    @State private var selectedEmployee: EmployeeEntity?
    @State private var date = Date()
    @State private var fullDay = false
    @State private var startHour: Int = 9
    @State private var endHour: Int = 18

    var body: some View {
        Form {

            // ===== СОТРУДНИК =====
            Section(header: Text("Сотрудник")) {
                Picker("Выбери сотрудника", selection: $selectedEmployee) {
                    ForEach(employees) { emp in
                        Text(emp.fullName ?? "—")
                            .tag(emp as EmployeeEntity?)
                    }
                }
            }

            // ===== ДАТА =====
            Section(header: Text("Дата")) {
                DatePicker(
                    "Дата смены",
                    selection: $date,
                    displayedComponents: .date
                )
            }

            // ===== ТИП СМЕНЫ =====
            Section {
                Toggle("Полный день", isOn: $fullDay)
            }

            // ===== ВРЕМЯ =====
            if !fullDay {
                Section(header: Text("Время")) {
                    Stepper("Начало: \(startHour):00", value: $startHour, in: 0...23)
                    Stepper("Конец: \(endHour):00", value: $endHour, in: 0...23)
                }
            }

            // ===== СОХРАНИТЬ =====
            Section {
                Button("Создать смену") {
                    createShift()
                }
                .disabled(selectedEmployee == nil)
            }
        }
        .navigationTitle("Новая смена")
    }

    // MARK: - CREATE

    private func createShift() {
        guard let employee = selectedEmployee else { return }

        let shift = ShiftEntity(context: context)
        shift.id = UUID()
        shift.date = date
        shift.department = employee.department
        shift.fullDay = fullDay
        shift.startHour = fullDay ? 0 : Int16(startHour)
        shift.endHour = fullDay ? 0 : Int16(endHour)
        shift.employee = employee

        do {
            try context.save()
            dismiss()
        } catch {
            print("❌ Shift save error:", error)
        }
    }
}
