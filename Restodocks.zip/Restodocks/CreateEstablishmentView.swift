import SwiftUI

struct CreateEstablishmentView: View {

    @EnvironmentObject var accounts: AccountManager
    @State private var name = ""

    var body: some View {
        Form {

            Section("Компания") {
                TextField("Название компании", text: $name)
            }

            Section {
                Button("Зарегистрировать компанию") {
                    accounts.createEstablishment(name: name)
                }
                .disabled(name.isEmpty)
            }
        }
        .navigationTitle("Регистрация компании")
    }
}
