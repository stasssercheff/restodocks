//
//  SushiBarMenuView.swift
//  Restodocks
//
//  Created by Stanislav Rebrikov on 1/6/26.
//


//
//  SushiBarMenuView.swift
//  Restodocks
//
//  Created by Stanislav Rebrikov on 1/6/26.
//

import SwiftUI

struct SushiBarMenuView: View {
    var body: some View {
        Text("Sushi Bar • Menu")
            .navigationTitle("Menu")
    }
}