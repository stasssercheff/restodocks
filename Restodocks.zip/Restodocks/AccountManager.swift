//
//  AccountManager.swift
//  Restodocks
//

import Foundation
import CoreData
import Combine

final class AccountManager: ObservableObject {

    private let context =
        PersistenceController.shared.container.viewContext

    // связь с AppState (НЕ дублируем логику)
    weak var appState: AppState?

    @Published var establishment: EstablishmentEntity?
    @Published var currentEmployee: EmployeeEntity?

    init() {
        loadEstablishment()
        loadActiveEmployee()
    }

    // MARK: - COMPANY
    func createEstablishment(name: String) {

        let entity = EstablishmentEntity(context: context)
        entity.id = UUID()
        entity.name = name
        entity.pinCode = Self.generatePin()

        saveContext()

        establishment = entity
        appState?.isCompanyCreated = true
    }

    // MARK: - OWNER
    func createOwner(
        fullName: String,
        email: String,
        password: String
    ) {
        guard let company = establishment else { return }

        let owner = EmployeeEntity(context: context)
        owner.id = UUID()
        owner.fullName = fullName
        owner.email = email
        owner.password = password
        owner.rolesArray = ["owner"]
        owner.isActive = true
        owner.pinCode = company.pinCode
        owner.department = "management"

        saveContext()

        currentEmployee = owner
        appState?.isLoggedIn = true
    }

    // MARK: - LOAD
    private func loadEstablishment() {
        let req: NSFetchRequest<EstablishmentEntity> =
            EstablishmentEntity.fetchRequest()
        req.fetchLimit = 1
        establishment = try? context.fetch(req).first

        if establishment != nil {
            appState?.isCompanyCreated = true
        }
    }

    private func loadActiveEmployee() {
        let req: NSFetchRequest<EmployeeEntity> =
            EmployeeEntity.fetchRequest()
        req.predicate = NSPredicate(format: "isActive == YES")
        req.fetchLimit = 1

        if let emp = try? context.fetch(req).first {
            currentEmployee = emp
            appState?.isLoggedIn = true
        }
    }

    func logout() {
        currentEmployee?.isActive = false
        saveContext()
        currentEmployee = nil
        appState?.isLoggedIn = false
    }

    private func saveContext() {
        try? context.save()
    }

    private static func generatePin() -> String {
        let chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        return String((0..<6).compactMap { _ in chars.randomElement() })
    }
}
