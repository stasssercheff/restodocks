//
//  QuickActionView.swift
//  Restodocks
//
//  Created by Stanislav Rebrikov on 1/20/26.
//


import SwiftUI

struct QuickActionView: View {
    var body: some View {
        Text("Быстрое действие")
            .font(.largeTitle)
    }
}