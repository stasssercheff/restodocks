//
//  ShiftCountingMode.swift
//  Restodocks
//
//  Created by Stanislav Rebrikov on 1/10/26.
//


enum ShiftCountingMode {
    case hourly     // считать часы
    case perShift   // считать смены
}