//
//  PersonalCabinetView.swift
//  Restodocks
//
//  Created by Stanislav Rebrikov on 1/20/26.
//


import SwiftUI

struct PersonalCabinetView: View {
    var body: some View {
        Text("Личный кабинет")
            .font(.largeTitle)
    }
}