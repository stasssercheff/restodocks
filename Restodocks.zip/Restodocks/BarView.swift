import SwiftUI

struct BarView: View {
    var body: some View {
        List {
            NavigationLink {
                BarMenuView()
            } label: {
                Text("Menu")
            }

            NavigationLink {
                BarTTKView()
            } label: {
                Text("TTK")
            }

            NavigationLink {
                BarScheduleView()
            } label: {
                Text("Schedule")
            }
        }
        .navigationTitle("Bar")
    }
}
