//
//  ColdKitchenTTKView.swift
//  Restodocks
//
//  Created by Stanislav Rebrikov on 1/6/26.
//


import SwiftUI

struct ColdKitchenTTKView: View {
    var body: some View {
        Text("Cold Kitchen TTK")
    }
}