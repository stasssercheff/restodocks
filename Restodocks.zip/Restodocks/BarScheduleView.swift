//
//  BarScheduleView.swift
//  Restodocks
//
//  Created by Stanislav Rebrikov on 1/6/26.
//


import SwiftUI

struct BarScheduleView: View {
    var body: some View {
        Text("Bar Schedule")
    }
}