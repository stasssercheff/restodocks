//
//  SushiBarTTKView.swift
//  Restodocks
//
//  Created by Stanislav Rebrikov on 1/6/26.
//


//
//  SushiBarTTKView.swift
//  Restodocks
//
//  Created by Stanislav Rebrikov on 1/6/26.
//

import SwiftUI

struct SushiBarTTKView: View {
    var body: some View {
        Text("Sushi Bar • TTK")
            .navigationTitle("TTK")
    }
}