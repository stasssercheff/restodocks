import SwiftUI

struct CreateOwnerView: View {

    @EnvironmentObject var accounts: AccountManager

    @State private var fullName = ""
    @State private var email = ""
    @State private var password = ""

    var body: some View {
        Form {

            Section("Владелец") {
                TextField("Имя", text: $fullName)

                TextField("Email", text: $email)
                    .keyboardType(.emailAddress)
                    .textInputAutocapitalization(.never)

                SecureField("Пароль", text: $password)
            }

            Section {
                Button("Создать владельца") {
                    accounts.createOwner(
                        fullName: fullName,
                        email: email,
                        password: password
                    )
                }
                .disabled(fullName.isEmpty || email.isEmpty || password.isEmpty)
            }
        }
        .navigationTitle("Владелец компании")
    }
}
