//
//  SushiBarScheduleView.swift
//  Restodocks
//
//  Created by Stanislav Rebrikov on 1/6/26.
//


//
//  SushiBarScheduleView.swift
//  Restodocks
//
//  Created by Stanislav Rebrikov on 1/6/26.
//

import SwiftUI

struct SushiBarScheduleView: View {
    var body: some View {
        Text("Sushi Bar • Schedule")
            .navigationTitle("Schedule")
    }
}