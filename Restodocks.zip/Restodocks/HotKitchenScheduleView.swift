//
//  HotKitchenScheduleView.swift
//  Restodocks
//
//  Created by Stanislav Rebrikov on 1/6/26.
//


import SwiftUI

struct HotKitchenScheduleView: View {
    var body: some View {
        Text("Hot Kitchen Schedule")
    }
}