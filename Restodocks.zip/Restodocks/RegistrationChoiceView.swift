import SwiftUI

struct RegistrationChoiceView: View {

    var body: some View {
        VStack(spacing: 24) {

            Spacer()

            NavigationLink {
                CreateEstablishmentView()
            } label: {
                Text("Регистрация компании")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(.blue)
                    .foregroundColor(.white)
                    .cornerRadius(12)
            }

            NavigationLink {
                EmployeeRegistrationView()
            } label: {
                Text("Регистрация сотрудника")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(.gray)
                    .foregroundColor(.white)
                    .cornerRadius(12)
            }

            Spacer()
        }
        .padding()
        .navigationTitle("Добро пожаловать")
    }
}
