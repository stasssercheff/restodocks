//
//  HotKitchenTTKView.swift
//  Restodocks
//
//  Created by Stanislav Rebrikov on 1/6/26.
//


import SwiftUI

struct HotKitchenTTKView: View {
    var body: some View {
        Text("Hot Kitchen TTK")
    }
}