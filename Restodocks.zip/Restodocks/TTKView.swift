//
//  TTKView.swift
//  Restodocks
//
//  Created by Stanislav Rebrikov on 12/22/25.
//


import SwiftUI

struct TTKView: View {
    var body: some View {
        Text("TTK")
    }
}