//
//  KitchenRootView.swift
//  Restodocks
//

import SwiftUI

struct KitchenRootView: View {

    @ObservedObject var lang = LocalizationManager.shared
    @EnvironmentObject var pro: ProAccess

    var body: some View {
        List {

            // ===== ОБЩИЕ ЦЕХА =====
            NavigationLink {
                KitchenSectionView(section: .hotKitchen)
            } label: {
                Text(lang.t("hot_kitchen"))
            }

            NavigationLink {
                KitchenSectionView(section: .coldKitchen)
            } label: {
                Text(lang.t("cold_kitchen"))
            }

            // ===== PRO ЦЕХА =====
            if pro.isPro {

                NavigationLink {
                    KitchenSectionView(section: .grill)
                } label: {
                    Text(lang.t("grill"))
                }

                NavigationLink {
                    KitchenSectionView(section: .pizza)
                } label: {
                    Text(lang.t("pizza"))
                }

                NavigationLink {
                    KitchenSectionView(section: .sushiBar)
                } label: {
                    Text(lang.t("sushi_bar"))
                }

                NavigationLink {
                    KitchenSectionView(section: .bakery)
                } label: {
                    Text(lang.t("bakery"))
                }

            } else {

                NavigationLink {
                    ProUnlockView()
                } label: {
                    Text("\(lang.t("grill")) (PRO)")
                }

                NavigationLink {
                    ProUnlockView()
                } label: {
                    Text("\(lang.t("pizza")) (PRO)")
                }

                NavigationLink {
                    ProUnlockView()
                } label: {
                    Text("\(lang.t("sushi_bar")) (PRO)")
                }

                NavigationLink {
                    ProUnlockView()
                } label: {
                    Text("\(lang.t("bakery")) (PRO)")
                }
            }

            // ===== ПРОЧЕЕ =====
            NavigationLink {
                KitchenSectionView(section: .pastry)
            } label: {
                Text(lang.t("pastry"))
            }

            NavigationLink {
                KitchenSectionView(section: .prep)
            } label: {
                Text(lang.t("prep"))
            }
        }
        .navigationTitle(lang.t("kitchen_title"))
    }
}
