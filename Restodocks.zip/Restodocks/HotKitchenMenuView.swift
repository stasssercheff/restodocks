//
//  HotKitchenMenuView.swift
//  Restodocks
//
//  Created by Stanislav Rebrikov on 1/6/26.
//


import SwiftUI

struct HotKitchenMenuView: View {
    var body: some View {
        Text("Hot Kitchen Menu")
    }
}