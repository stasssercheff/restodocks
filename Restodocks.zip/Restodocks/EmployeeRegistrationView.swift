//
//  EmployeeRegistrationView.swift
//  Restodocks
//

import SwiftUI
import CoreData

struct EmployeeRegistrationView: View {

    @Environment(\.managedObjectContext) private var context
    @EnvironmentObject var accounts: AccountManager
    @Environment(\.dismiss) private var dismiss

    // MARK: - FORM

    @State private var fullName = ""
    @State private var email = ""
    @State private var password = ""
    @State private var pin = ""

    @State private var selectedRole: String = "chef"

    private let availableRoles: [String] = [
        "chef",
        "manager",
        "waiter",
        "cashier"
    ]

    var body: some View {

        Form {

            Section(header: Text("Сотрудник")) {
                TextField("Имя и фамилия", text: $fullName)

                TextField("Email", text: $email)
                    .keyboardType(.emailAddress)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled(true)

                SecureField("Пароль", text: $password)
            }

            Section(header: Text("Компания")) {
                TextField("PIN компании", text: $pin)
                    .textInputAutocapitalization(.characters)
            }

            Section(header: Text("Роль")) {
                Picker("Должность", selection: $selectedRole) {
                    ForEach(availableRoles, id: \.self) { role in
                        Text(role.capitalized).tag(role)
                    }
                }
            }

            Section {
                Button("Зарегистрировать") {
                    registerEmployee()
                }
                .disabled(!canRegister)
            }
        }
        .navigationTitle("Регистрация сотрудника")
    }

    // MARK: - REGISTER

    private func registerEmployee() {

        guard
            let company = accounts.establishment,
            company.pinCode == pin
        else {
            print("❌ Wrong PIN")
            return
        }

        let employee = EmployeeEntity(context: context)
        employee.id = UUID()
        employee.fullName = fullName
        employee.email = email
        employee.password = password
        employee.pinCode = pin
        employee.rolesArray = [selectedRole]
        employee.isActive = true
        employee.department = selectedRole

        do {
            try context.save()
            dismiss()
            print("✅ Employee registered:", fullName)
        } catch {
            print("❌ Employee save error:", error)
        }
    }

    private var canRegister: Bool {
        !fullName.isEmpty &&
        !email.isEmpty &&
        !password.isEmpty &&
        !pin.isEmpty
    }
}
