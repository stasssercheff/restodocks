//
//  MenuView.swift
//  Restodocks
//
//  Created by Stanislav Rebrikov on 12/22/25.
//


import SwiftUI

struct MenuView: View {
    var body: some View {
        Text("Menu")
    }
}