//
//  BarTTKView.swift
//  Restodocks
//
//  Created by Stanislav Rebrikov on 1/6/26.
//


import SwiftUI

struct BarTTKView: View {
    var body: some View {
        Text("Bar TTK")
    }
}