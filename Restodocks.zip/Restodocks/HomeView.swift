// HomeView.swift
import SwiftUI

struct HomeView: View {

    @ObservedObject var lang = LocalizationManager.shared

    var body: some View {
        List {

            NavigationLink {
                ScheduleView()
            } label: {
                HomeButton(title: lang.t("schedule"))
            }

            NavigationLink {
                KitchenMenuView()
            } label: {
                HomeButton(title: lang.t("menu"))
            }

            NavigationLink {
                TTKView()
            } label: {
                HomeButton(title: lang.t("ttk"))
            }

            NavigationLink {
                StaffView()
            } label: {
                HomeButton(title: lang.t("staff"))
            }

            NavigationLink {
                SettingsView()
            } label: {
                HomeButton(title: lang.t("settings"))
            }
        }
        .navigationTitle(lang.t("app_name"))
    }
}
