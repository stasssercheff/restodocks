//
//  PizzaScheduleView.swift
//  Restodocks
//
//  Created by Stanislav Rebrikov on 1/6/26.
//


import SwiftUI
struct PizzaScheduleView: View { var body: some View { Text("Pizza Schedule") } }