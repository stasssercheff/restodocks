//
//  PizzaMenuView.swift
//  Restodocks
//
//  Created by Stanislav Rebrikov on 1/6/26.
//


import SwiftUI
struct PizzaMenuView: View { var body: some View { Text("Pizza Menu") } }