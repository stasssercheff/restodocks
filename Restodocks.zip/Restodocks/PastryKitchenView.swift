//
//  PastryKitchenView.swift
//  Restodocks
//
//  Created by Stanislav Rebrikov on 1/6/26.
//


import SwiftUI

struct PastryKitchenView: View {
    var body: some View {
        Text("Pastry Section")
    }
}