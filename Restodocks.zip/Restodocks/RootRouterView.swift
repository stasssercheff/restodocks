//
//  RootRouterView.swift
//  Restodocks
//

import SwiftUI

struct RootRouterView: View {

    @EnvironmentObject var appState: AppState

    var body: some View {
        Group {

            // 1️⃣ выбор (как было)
            if !appState.isCompanyCreated {
                NavigationStack {
                    RegistrationChoiceView()
                }

            // 2️⃣ владелец
            } else if !appState.isLoggedIn {
                NavigationStack {
                    CreateOwnerView()
                }

            // 3️⃣ приложение
            } else {
                TabRootView()
            }
        }
    }
}
