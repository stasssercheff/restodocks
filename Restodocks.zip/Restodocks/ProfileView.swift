//
//  ProfileView.swift
//  Restodocks
//

import SwiftUI

struct ProfileView: View {

    @EnvironmentObject var accounts: AccountManager

    var body: some View {

        VStack(spacing: 20) {

            Text("Профиль")
                .font(.title2)
                .bold()

            if let establishment = accounts.establishment {
                Text(establishment.name ?? "—")
                    .foregroundColor(.secondary)
            }

            Button(role: .destructive) {
                accounts.logout()
            } label: {
                Text("Выйти")
            }

            Spacer()
        }
        .padding()
    }
}
