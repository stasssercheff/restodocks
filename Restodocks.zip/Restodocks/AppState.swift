//
//  AppState.swift
//  Restodocks
//

import Foundation
import Combine

final class AppState: ObservableObject {

    /// компания создана
    @Published var isCompanyCreated: Bool = false

    /// пользователь вошёл (владелец или сотрудник)
    @Published var isLoggedIn: Bool = false
}
