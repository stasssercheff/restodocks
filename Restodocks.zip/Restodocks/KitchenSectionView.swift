//
//  KitchenSectionView.swift
//  Restodocks
//

import SwiftUI

struct KitchenSectionView: View {

    let section: KitchenSection
    @ObservedObject var lang = LocalizationManager.shared

    var body: some View {
        Text(lang.t(titleKey))
            .font(.headline)
    }

    private var titleKey: String {
        switch section {
        case .hotKitchen:
            return "hot_kitchen"
        case .coldKitchen:
            return "cold_kitchen"
        case .prep:
            return "prep"
        case .pastry:
            return "pastry"
        case .grill:
            return "grill"
        case .pizza:
            return "pizza"
        case .sushiBar:
            return "sushi_bar"
        case .bakery:
            return "bakery"
        case .cleaning:
            return "cleaning"
        case .kitchenManagement:
            return "kitchen_management"
        }
    }
}
