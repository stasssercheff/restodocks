# Настройка Supabase в Flutter приложении

## 🚀 Что было сделано

### 1. Добавлены зависимости
В `pubspec.yaml` добавлены:
- `supabase_flutter: ^2.0.0` - основной клиент Supabase для Flutter
- `flutter_dotenv: ^5.1.0` - для работы с переменными окружения

### 2. Создан файл .env
В корне проекта создан файл `.env` с конфигурацией Supabase:
```env
SUPABASE_URL=https://ваш-проект.supabase.co
SUPABASE_ANON_KEY=ваш_anon_key
```

### 3. Настроена инициализация в main.dart
```dart
void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Загрузка переменных окружения
  await dotenv.load(fileName: ".env");

  // Инициализация Supabase
  await Supabase.initialize(
    url: dotenv.env['SUPABASE_URL']!,
    anonKey: dotenv.env['SUPABASE_ANON_KEY']!,
  );

  // Инициализация сервисов
  await LocalizationService.initialize();

  runApp(const RestodocksApp());
}
```

### 4. Создан SupabaseService
Сервис для работы с Supabase API:
- Аутентификация пользователей
- Работа с базой данных
- Загрузка файлов в Storage
- Реал-тайм подписки

### 5. Добавлен тестовый экран
Экран `/supabase-test` для проверки подключения и тестирования функций.

## 🔧 Как использовать

### Доступ к Supabase клиенту
```dart
final supabase = SupabaseService().client;
```

### Аутентификация
```dart
// Вход
final response = await SupabaseService().signInWithEmail(email, password);

// Регистрация
final response = await SupabaseService().signUpWithEmail(email, password);

// Выход
await SupabaseService().signOut();

// Текущий пользователь
final user = SupabaseService().currentUser;
```

### Работа с базой данных
```dart
// Получение данных
final data = await SupabaseService().getData('table_name');

// Вставка данных
final newRecord = await SupabaseService().insertData('table_name', {
  'name': 'Test',
  'value': 123,
});

// Обновление данных
final updated = await SupabaseService().updateData(
  'table_name',
  {'status': 'active'},
  'id',
  recordId,
);

// Удаление данных
await SupabaseService().deleteData('table_name', 'id', recordId);
```

### Работа с файлами (Storage)
```dart
// Загрузка файла
final path = await SupabaseService().uploadFile(
  'bucket_name',
  'file_name.jpg',
  fileBytes,
);

// Получение URL файла
final url = SupabaseService().getFileUrl('bucket_name', 'file_name.jpg');

// Удаление файла
await SupabaseService().deleteFile('bucket_name', 'file_name.jpg');
```

## 📱 Тестирование

1. Запустите приложение:
   ```bash
   flutter run -d chrome
   ```

2. Войдите в систему или зарегистрируйтесь

3. Перейдите в Профиль → "Тест Supabase"

4. Проверьте статус подключения и протестируйте функции

## 🔒 Безопасность

- Файл `.env` добавлен в `.gitignore`
- Никогда не коммитьте реальные ключи в репозиторий
- Используйте RLS (Row Level Security) в Supabase
- Настройте правильные политики доступа

## 📋 Следующие шаги

#### Шаг 1: Создание таблиц
1. Откройте [Supabase Dashboard](https://supabase.com/dashboard)
2. Выберите ваш проект
3. Перейдите в **SQL Editor**
4. Откройте файл `supabase_tables.sql`
5. **СКОПИРУЙТЕ содержимое файла** (не сам файл!)
6. Вставьте в SQL Editor и нажмите **Run**

#### Шаг 2: Добавление данных
1. Откройте файл `supabase_data.sql`
2. Скопируйте содержимое
3. Вставьте в новый запрос SQL Editor
4. Нажмите **Run**

#### Шаг 3: Настройка безопасности
1. Откройте файл `supabase_policies.sql`
2. Скопируйте содержимое
3. Вставьте в новый запрос SQL Editor
4. Нажмите **Run**

#### Шаг 4: Индексы и триггеры
1. Откройте файл `supabase_indexes.sql`
2. Скопируйте содержимое
3. Вставьте в новый запрос SQL Editor
4. Нажмите **Run**

### 📋 Следующие шаги в разработке

1. **Заменить локальное хранилище** на Supabase в сервисах
2. **Добавить синхронизацию данных** между локальным и облачным хранилищем
3. **Настроить аутентификацию** через Supabase Auth
4. **Добавить загрузку изображений** в Supabase Storage

## 🆘 Проблемы и решения

### Ошибка подключения
- Проверьте правильность URL и ключа в `.env`
- Убедитесь, что проект Supabase активен
- Проверьте подключение к интернету

### Ошибка аутентификации
- Проверьте настройки аутентификации в Supabase Dashboard
- Убедитесь, что email подтвержден (если требуется)

### Ошибка доступа к таблицам
- Настройте RLS политики в Supabase
- Проверьте права пользователя

## 📞 Контакты

При проблемах с Supabase обратитесь к документации: https://supabase.com/docs